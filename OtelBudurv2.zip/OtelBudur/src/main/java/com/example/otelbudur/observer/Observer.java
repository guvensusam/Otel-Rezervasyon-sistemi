package com.example.otelbudur.observer;

public interface Observer {
    void update(String message);
}